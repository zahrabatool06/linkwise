
  # Links Website in Next.js

  This is a code bundle for Links Website in Next.js. The original project is available at https://www.figma.com/design/n93hj9dtvRfxuEvi6UYPCA/Links-Website-in-Next.js.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  